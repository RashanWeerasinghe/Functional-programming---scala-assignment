object ticket{


def main(args:Array[String])
{
var ticket_price1=15;
var ticket_price2=10;
var ticket_price3=20;
var t15people =120;
var t10people=140;
var t20people=100;
var flimcost=500;
var peoplecost=3;
var p1=profit1(ticket_price1,t15people,flimcost,peoplecost);
var p2=profit2(ticket_price2,t10people,flimcost,peoplecost);
var p3=profit3(ticket_price3,t20people,flimcost,peoplecost);
last(p1,p2,p3,ticket_price1,ticket_price2,ticket_price3);

println("profit1 15 ticket is="+p1);
println("profit2 10 ticket is="+p2);
println("profit3 20 ticket is="+p3);



}

def profit1(t:Double,x:Double,f:Double,p:Double):Double={
  t*x-f-(p*x);
}



def profit2(t:Double,y:Double,f:Double,p:Double):Double={
  t*y-f-(p*y);
}



def profit3(t:Double,z:Double,f:Double,p:Double):Double={
   t*z-f-(p*z);
}

def last(p1:Double,p2:Double,p3:Double,ticket_price1:Double,ticket_price2:Double,ticket_price3:Double):Unit={
if(p1>=p2)
{ println(" ");
  if(p1>=p3)
    { println(" ");
       println("best profit ticket is="+ ticket_price1);
       println("best profit is="+p1);
     }
}

else 
     println(" ");
     {if(p2>=p3)
     { 
       println("best profit ticket is="+ ticket_price2);
       println("best profit is="+p2);

       }
      else
        { println(" ");
          println("best profit ticket is="+ ticket_price3);
         println("best profit is="+p3);
       }
}

}





}