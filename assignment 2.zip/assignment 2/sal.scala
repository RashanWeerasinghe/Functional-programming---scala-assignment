object sal{
def main(args:Array[String])
{

var normal_hour_rate=150;
var ot_hour_rate=75;

def salary(x:Double,y:Double):Double={
((x*40+y*20)*90)/100;

}

var fullsalary=salary(normal_hour_rate,ot_hour_rate);

println("salary is="+fullsalary);


}




}