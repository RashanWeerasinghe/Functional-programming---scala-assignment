object third{
def main(args:Array[String]){

var n=scala.io.StdIn.readInt()
var k=sum(n)
println(k)
}

def sum(n:Int):Int={
if(n >= 1){
       
    return (n + sum(n - 1));
}
else
{
return n;
}
}



}


