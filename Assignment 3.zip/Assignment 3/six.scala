object six{

def main(args:Array[String]):Unit={
var n=scala.io.StdIn.readInt()
fibnum(n)

}
def fibnum(n:Int):Unit={

var f1 = 0
var f2 = 1
  
    if(n > 1) {
  
    for (i <- 1 to n) 
    { 
        println(f2); 

        var next = f1 + f2; 

        f1 = f2; 

        f2 = next; 
    } 
}

}




}





