object four{

def main(args:Array[String]):Int={
var n=scala.io.StdIn.readInt()
fun(n);


}


def fun(n:Int):Boolean={

 if(n==0){
        return(true);
    }else if (n == 1){
        return(false);
    }else {
        return(fun(n-2));
    }

}
}







