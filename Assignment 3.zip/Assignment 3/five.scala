object five{

def main(args:Array[String]){
var n=scala.io.StdIn.readInt()
var k= sum(n);

println("sum="+k);
}

def sum(n:Int):Int={
if(n % 2 == 0) 
{
  
  return (n + sum(n - 2));
}
else
{
return sum(n-1);
}

}
}