object sale{

def main(args:Array[String])
{
var coverprice=24.95;
var discount=0.4;
var shipcost=3;
var addshipcost=3.75;

def shippingcost(a:Double,b:Double):Double={

a*50+b*10;
}

var allshipcost=shippingcost(shipcost,addshipcost);

def salecost(c:Double,d:Double,cs:Double):Double={

   (c+c*d)*60 + cs;
}

var allcost=salecost(coverprice,discount,allshipcost);
println("the total wholesale cost for 60 copies ="+allcost);


}


}