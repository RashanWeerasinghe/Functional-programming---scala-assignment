object tem{
     def main(args:Array[String])
{
    def converttemp(c:Int):Double=c*1.8000+32.00
 var F=converttemp(35)
println("Fahrenheit Temperature:"+F);

}



}