object volofsp{
def main(args:Array[String])
{
def  volume(v:Int):Double={3.14*(v*v*v)*4/3;}

println("volume of a sphere ="+ volume(5));

}

}
